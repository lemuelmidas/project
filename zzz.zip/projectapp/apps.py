from django.apps import AppConfig


class ProjectappConfig(AppConfig):
    name = 'projectapp'
