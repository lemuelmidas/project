from django.urls import path
from .views import Home, About, Contact, Car
urlpatterns=[
	path('car/',Car.as_view(), name='car'),
	path('contact/',Contact.as_view(), name='contact'),
	path('about/',About.as_view(), name='about'),
    path('',Home.as_view(), name='home'),
]
